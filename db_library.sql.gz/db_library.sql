-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2023 at 09:27 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_adminlogin`
--

CREATE TABLE `tb_adminlogin` (
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_adminlogin`
--

INSERT INTO `tb_adminlogin` (`username`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `tb_craeatstudentaccount`
--

CREATE TABLE `tb_craeatstudentaccount` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `section` text NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `branch` text NOT NULL,
  `year` int(11) NOT NULL,
  `imgname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_craeatstudentaccount`
--

INSERT INTO `tb_craeatstudentaccount` (`id`, `name`, `password`, `section`, `email`, `mobile`, `branch`, `year`, `imgname`) VALUES
(1, 'bhupesh meshram', 'bhupesh123', 'A', 'bmeshram@gmail.com', '9765286811', 'MECHANICAL', 2022, 'images (2).jpeg'),
(2, 'prohit bagde', 'prohit123', 'A', 'pbagde@gmail.com', '9876543211', 'CS', 2021, 'images (2).jpeg'),
(3, 'ritik larorkar', 'ritik123', 'B', ' ritik@gmail.com', ' 9087654321', 'CS', 2021, 'images (3).jpeg'),
(4, 'yash yennewar', 'yash123', 'A', 'yash@gmail.com', '9876540321', 'CS', 2023, 'images (3).jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_creatlibaccount`
--

CREATE TABLE `tb_creatlibaccount` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `city` text NOT NULL,
  `mobile_no` text NOT NULL,
  `gmail` text NOT NULL,
  `salary` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_creatlibaccount`
--

INSERT INTO `tb_creatlibaccount` (`id`, `name`, `password`, `city`, `mobile_no`, `gmail`, `salary`, `img`) VALUES
(4, 'bhupesh meshram', 'bhupesh123', 'nagpur', '9765286811', 'bmeshram@gmail.com', '20000', 'images (1).jpeg'),
(5, 'tejas bagde', 'tejas123', 'nagpur', '9075873760', 'tbagde@gmail.com', '25000', 'boy2.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_issuebook`
--

CREATE TABLE `tb_issuebook` (
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_name` text NOT NULL,
  `book_author` text NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `issue_date` text NOT NULL,
  `return_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_issuebook`
--

INSERT INTO `tb_issuebook` (`student_id`, `book_id`, `book_name`, `book_author`, `available_quantity`, `issue_date`, `return_date`) VALUES
(1, 3, 'JavaTheCompleteReference', ' Herbert Schildt', 10, '10/04/2023', '10/04/2023'),
(2, 1, 'let us c', '     Yashavant P. Kanetkar', 10, '10/04/2023', '10/04/2023'),
(3, 3, 'JavaTheCompleteReference', ' Herbert Schildt', 10, '10/04/2023', '10/05/2023'),
(1, 1, 'let us c', '     Yashavant P. Kanetkar', 10, '10/04/2023', '30/04/2023'),
(0, 0, ' ', ' ', 0, ' ', ' '),
(0, 0, ' ', ' ', 0, ' ', ' '),
(0, 0, ' ', ' ', 0, ' ', ' '),
(0, 0, ' ', ' ', 0, ' ', ' '),
(0, 0, ' ', ' ', 0, ' ', ' '),
(0, 0, ' ', ' ', 0, ' ', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `tb_returnbook`
--

CREATE TABLE `tb_returnbook` (
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_name` text NOT NULL,
  `book_author` text NOT NULL,
  `book_quantity` int(11) NOT NULL,
  `return_date` text NOT NULL,
  `curren_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_returnbook`
--

INSERT INTO `tb_returnbook` (`student_id`, `book_id`, `book_name`, `book_author`, `book_quantity`, `return_date`, `curren_date`) VALUES
(3, 3, ' JavaTheCompleteReference', '  Herbert Schildt', 10, ' 10/05/2023', '15/04/2023');

-- --------------------------------------------------------

--
-- Table structure for table `tb_studentbookrequest`
--

CREATE TABLE `tb_studentbookrequest` (
  `student_id` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `book_name` text NOT NULL,
  `book_author` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_studentbookrequest`
--

INSERT INTO `tb_studentbookrequest` (`student_id`, `student_name`, `book_name`, `book_author`) VALUES
(1, 'bhupesh meshram', 'let us c', '     Yashavant P. Kanetkar'),
(1, 'bhupesh meshram', ' ', ' '),
(1, 'bhupesh meshram', 'let us c', '     Yashavant P. Kanetkar');

-- --------------------------------------------------------

--
-- Table structure for table `tb_updatelibrecord`
--

CREATE TABLE `tb_updatelibrecord` (
  `book_id` int(11) NOT NULL,
  `book_name` text NOT NULL,
  `book_author` text NOT NULL,
  `quantity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_updatelibrecord`
--

INSERT INTO `tb_updatelibrecord` (`book_id`, `book_name`, `book_author`, `quantity`) VALUES
(1, 'let us c', '    Yashavant P. Kanetkar', '    10'),
(2, 'ANSI C', 'E. Balagurusamy', '   10'),
(3, 'JavaTheCompleteReference', 'Herbert Schildt', '   10'),
(4, 'xyz', 'xyz', '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_creatlibaccount`
--
ALTER TABLE `tb_creatlibaccount`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_creatlibaccount`
--
ALTER TABLE `tb_creatlibaccount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
